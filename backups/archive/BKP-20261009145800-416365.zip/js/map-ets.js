/**
 * NORTH-005 OmniERP — Employee Tracking System (ETS) & GIS Map Engine
 * Precision STL BOOTH Geolocation & Live Master Registry GPS Mapping
 */

(function () {
  'use strict';

  // Centralized Municipality -> Color Mapping Configuration (Section 7 & 8)
  // Panabo City = GREEN, Sto. Tomas = YELLOW, Carmen = RED, Kapalong = BLUE, Tagum City = PURPLE, Talaingod = PINK, Samal = CYAN
  const DEFAULT_MUNICIPALITY_COLORS = {
    'Panabo City': '#10b981',  // GREEN
    'Panabo': '#10b981',
    'Sto. Tomas': '#eab308',   // YELLOW
    'Santo Tomas': '#eab308',
    'Carmen': '#ef4444',       // RED
    'Kapalong': '#3b82f6',     // BLUE
    'Tagum City': '#8b5cf6',   // PURPLE
    'Tagum': '#8b5cf6',
    'Talaingod': '#ec4899',    // PINK
    'Samal': '#06b6d4',        // CYAN
    'Island Garden City of Samal': '#06b6d4',
    'Asuncion': '#f97316',     // ORANGE
    'New Corella': '#14b8a6',  // TEAL
    'San Isidro': '#6366f1',   // INDIGO
    'Braulio E. Dujali': '#84cc16' // LIME
  };

  const MUNICIPALITY_FALLBACK_PALETTE = [
    '#10b981', '#eab308', '#ef4444', '#3b82f6', '#8b5cf6', 
    '#ec4899', '#06b6d4', '#f97316', '#14b8a6', '#6366f1', '#84cc16', '#d97706', '#059669'
  ];

  function getStoredMunicipalityColorMap() {
    try {
      const raw = localStorage.getItem('NORTH005_MUNI_COLORS');
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.warn('Could not parse stored muni colors', e);
    }
    return { ...DEFAULT_MUNICIPALITY_COLORS };
  }

  function saveMunicipalityColorMap(map) {
    try {
      localStorage.setItem('NORTH005_MUNI_COLORS', JSON.stringify(map));
    } catch (e) {
      console.warn('Could not persist muni colors', e);
    }
  }

  function resolveMunicipalityColor(muni) {
    if (!muni || muni === '-') return '#eab308';
    const cleanMuni = muni.trim();
    const map = getStoredMunicipalityColorMap();
    
    // Exact or case-insensitive match
    for (const [key, color] of Object.entries(map)) {
      if (key.toLowerCase() === cleanMuni.toLowerCase()) {
        return color;
      }
    }

    // Substring match (e.g. "Panabo" in "Panabo City")
    for (const [key, color] of Object.entries(map)) {
      if (cleanMuni.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(cleanMuni.toLowerCase())) {
        map[cleanMuni] = color;
        saveMunicipalityColorMap(map);
        return color;
      }
    }

    const usedColors = Object.values(map);
    const available = MUNICIPALITY_FALLBACK_PALETTE.find(c => !usedColors.includes(c)) || '#64748b';
    map[cleanMuni] = available;
    saveMunicipalityColorMap(map);
    return available;
  }

  /**
   * Helper: Normalize Booth Code to canonical "DDN-xxx" format.
   * Returns null for non-booth values ('-', 'N/A', empty, etc.) so roaming collectors/admins are excluded.
   */
  function normalizeBoothCode(code) {
    if (!code || typeof code !== 'string') return null;
    const trimmed = code.trim().toUpperCase();
    if (trimmed === '-' || trimmed === 'N/A' || trimmed === 'NONE' || trimmed === '' || trimmed === 'UNASSIGNED') {
      return null;
    }
    // Remove "BOOTH-" or "BOOTH " prefix
    let clean = trimmed.replace(/^BOOTH[\s-]*/i, '');
    // Normalize "DDN 760" or "DDN_760" -> "DDN-760"
    clean = clean.replace(/^DDN[\s_]+(\d+)/i, 'DDN-$1');
    // If digits only like "760", convert to "DDN-760"
    if (/^\d+$/.test(clean)) {
      clean = `DDN-${clean}`;
    }
    return clean;
  }

  /**
   * Robust GPS Coordinate Parser
   * Supports: numbers, string pairs ("7.5303, 125.6264"), latitude/longitude, lat/lng objects, arrays [lat, lng]
   * Enforces: Latitude = first coordinate, Longitude = second coordinate
   * Detects and corrects inverted coordinates (e.g. [125.x, 7.x] -> [7.x, 125.x])
   * Validates: Plausible Davao del Norte geographic bounding box and global bounds (-90..90, -180..180)
   */
  function parseGpsCoordinates(record) {
    if (!record) return { isValid: false, reason: 'GPS UNAVAILABLE' };

    let rawLat = record.lat !== undefined && record.lat !== null && record.lat !== '' ? record.lat : record.latitude;
    let rawLng = record.lng !== undefined && record.lng !== null && record.lng !== '' ? record.lng : record.longitude;

    // Check record.coordinates if object, array, or string
    if ((rawLat === undefined || rawLng === undefined) && record.coordinates) {
      if (typeof record.coordinates === 'object' && record.coordinates !== null) {
        if (Array.isArray(record.coordinates) && record.coordinates.length >= 2) {
          rawLat = record.coordinates[0];
          rawLng = record.coordinates[1];
        } else {
          rawLat = record.coordinates.lat !== undefined ? record.coordinates.lat : record.coordinates.latitude;
          rawLng = record.coordinates.lng !== undefined ? record.coordinates.lng : record.coordinates.longitude;
        }
      } else if (typeof record.coordinates === 'string' && record.coordinates.trim()) {
        const parts = record.coordinates.trim().split(/[,;\s]+/).filter(Boolean);
        if (parts.length >= 2) {
          rawLat = parts[0];
          rawLng = parts[1];
        }
      }
    }

    // Check if GPS is provided as a composite string e.g. "7.5303, 125.6264"
    const composite = record.gps || record.gps_coordinates || record.gpsCoordinates || record.rawCoordinates || record.coordinatesStr;
    if ((rawLat === undefined || rawLng === undefined) && typeof composite === 'string' && composite.trim()) {
      const parts = composite.trim().split(/[,;\s]+/).filter(Boolean);
      if (parts.length >= 2) {
        rawLat = parts[0];
        rawLng = parts[1];
      }
    }

    if (rawLat === undefined || rawLat === null || rawLat === '' || rawLng === undefined || rawLng === null || rawLng === '') {
      return { isValid: false, reason: 'GPS UNAVAILABLE' };
    }

    let lat = typeof rawLat === 'number' ? rawLat : parseFloat(String(rawLat).replace(/[^\d.-]/g, ''));
    let lng = typeof rawLng === 'number' ? rawLng : parseFloat(String(rawLng).replace(/[^\d.-]/g, ''));

    if (isNaN(lat) || isNaN(lng)) {
      return { isValid: false, reason: 'GPS INVALID' };
    }

    // Section 4: Coordinate Inversion Guard.
    // In Davao del Norte (Region XI, Philippines), Latitude is ~6.0°..9.0° N and Longitude is ~124.5°..127.0° E.
    // If coordinates were entered inverted as [longitude, latitude] e.g. [125.625, 7.524], lat is > 50 and lng is < 50.
    if (lat > 50 && lng < 50) {
      const temp = lat;
      lat = lng;
      lng = temp;
    }

    // Reject (0, 0) default coordinates
    if (lat === 0 && lng === 0) {
      return { isValid: false, reason: 'GPS INVALID (0,0)' };
    }

    // Global Latitude/Longitude Range Check
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return { isValid: false, reason: 'GPS OUT OF GLOBAL BOUNDS' };
    }

    // Section 6: Plausibility bounds check for Davao del Norte region
    const isPlausibleDavao = (lat >= 6.0 && lat <= 9.0 && lng >= 124.5 && lng <= 127.0);
    if (!isPlausibleDavao) {
      console.warn(`[GPS Validation Warning] Coordinate (${lat}, ${lng}) is outside Davao del Norte corridor.`);
    }

    // Valid coordinate
    return {
      lat: parseFloat(lat.toFixed(6)),
      lng: parseFloat(lng.toFixed(6)),
      isValid: true
    };
  }

  window.parseGpsCoordinates = parseGpsCoordinates;
  window.normalizeBoothCode = normalizeBoothCode;
  window.getMunicipalityColor = resolveMunicipalityColor;
  window.getMunicipalityColorMap = getStoredMunicipalityColorMap;

  // =========================================================================
  // SMART CACHING LAYER FOR MASTER REGISTRY GPS DATA (Sections 9-16)
  // =========================================================================
  const ETS_GPS_CACHE_STORAGE_KEY = 'NORTH005_ETS_GPS_CACHE_V1';
  const ETS_GPS_CACHE_TTL_MS = 15 * 60 * 1000; // 15 Minutes Safe Expiration TTL

  class EtsGpsCache {
    constructor() {
      this.memoryCache = null;
    }

    /**
     * Retrieves valid cached booth data if and only if:
     * 1. Cache exists and is valid JSON
     * 2. Cache version strictly matches expected current Master Registry Version
     * 3. Cache timestamp has not exceeded TTL (15 minutes)
     * 4. Cache structure passes integrity checks
     */
    getValidData(expectedVersion) {
      if (!expectedVersion) return null;

      // 1. Check in-memory cache first for instant performance
      if (this.memoryCache) {
        if (this._isValidCachePayload(this.memoryCache, expectedVersion)) {
          return this.memoryCache;
        } else {
          this.invalidate();
          return null;
        }
      }

      // 2. Check persistent storage (sessionStorage or localStorage)
      try {
        let raw = null;
        if (typeof sessionStorage !== 'undefined') {
          raw = sessionStorage.getItem(ETS_GPS_CACHE_STORAGE_KEY);
        }
        if (!raw && typeof localStorage !== 'undefined') {
          raw = localStorage.getItem(ETS_GPS_CACHE_STORAGE_KEY);
        }
        if (!raw) return null;

        const parsed = JSON.parse(raw);
        if (this._isValidCachePayload(parsed, expectedVersion)) {
          this.memoryCache = parsed;
          return parsed;
        } else {
          this.invalidate();
          return null;
        }
      } catch (e) {
        console.warn('[EtsGpsCache] Error reading cache, fallback to Master Registry:', e);
        this.invalidate();
        return null;
      }
    }

    /**
     * Strict validation of cache payload:
     * - Version match
     * - TTL freshness
     * - Booth array integrity (only numeric lat/lng within bounds)
     */
    _isValidCachePayload(payload, expectedVersion) {
      if (!payload || typeof payload !== 'object') return false;
      if (payload.version !== expectedVersion) return false;
      if (!payload.timestamp || (Date.now() - payload.timestamp > ETS_GPS_CACHE_TTL_MS)) return false;
      if (!Array.isArray(payload.booths)) return false;

      // Strict validation: every cached booth must have valid numeric coordinates
      for (const b of payload.booths) {
        if (!b.boothCode) return false;
        if (typeof b.lat !== 'number' || typeof b.lng !== 'number') return false;
        if (isNaN(b.lat) || isNaN(b.lng)) return false;
        if (b.lat < -90 || b.lat > 90 || b.lng < -180 || b.lng > 180) return false;
        if (b.lat === 0 && b.lng === 0) return false;
      }
      return true;
    }

    /**
     * Writes validated Master Registry data to cache.
     * Prevents caching of bad, non-numeric, or null coordinates.
     */
    setData(version, booths, uncoordinated = [], auditSummary = null) {
      if (!version) return;

      const validatedBooths = [];
      for (const b of booths) {
        if (!b || !b.boothCode) continue;
        const numLat = Number(b.lat);
        const numLng = Number(b.lng);
        if (isNaN(numLat) || isNaN(numLng)) continue;
        if (numLat < -90 || numLat > 90 || numLng < -180 || numLng > 180) continue;
        if (numLat === 0 && numLng === 0) continue;

        validatedBooths.push({
          boothCode: b.boothCode,
          personnel: b.personnel || 'Unassigned',
          staffList: Array.isArray(b.staffList) ? b.staffList.map(s => ({
            id: s.id,
            name: s.name,
            role: s.role || 'Sales Representative'
          })) : [],
          boothRecordId: b.boothRecordId || b.boothCode,
          municipality: b.municipality || 'Sto. Tomas',
          location: b.location || b.address || '-',
          lat: parseFloat(numLat.toFixed(6)),
          lng: parseFloat(numLng.toFixed(6)),
          status: b.status || 'Active',
          masterRegistryVersion: version,
          lastUpdated: new Date().toISOString()
        });
      }

      const payload = {
        version,
        timestamp: Date.now(),
        lastUpdated: new Date().toISOString(),
        booths: validatedBooths,
        uncoordinated: (uncoordinated || []).map(u => ({
          boothCode: u.boothCode,
          municipality: u.municipality || '-',
          reason: u.reason || 'GPS DATA MISSING'
        })),
        auditSummary: auditSummary || null
      };

      this.memoryCache = payload;

      try {
        const str = JSON.stringify(payload);
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.setItem(ETS_GPS_CACHE_STORAGE_KEY, str);
        }
        if (typeof localStorage !== 'undefined') {
          localStorage.setItem(ETS_GPS_CACHE_STORAGE_KEY, str);
        }
      } catch (e) {
        console.warn('[EtsGpsCache] Unable to persist cache:', e);
      }
    }

    /**
     * Explicit cache invalidation
     */
    invalidate() {
      this.memoryCache = null;
      try {
        if (typeof sessionStorage !== 'undefined') {
          sessionStorage.removeItem(ETS_GPS_CACHE_STORAGE_KEY);
        }
        if (typeof localStorage !== 'undefined') {
          localStorage.removeItem(ETS_GPS_CACHE_STORAGE_KEY);
        }
      } catch (e) {}
    }
  }

  window.etsGpsCache = new EtsGpsCache();

  class EtsMapEngine {
    constructor() {
      this.map = null;
      this.markers = {
        booths: L.layerGroup()
      };
      this.allMarkerInstances = {}; // mapped by boothCode and emp.id -> L.marker
      this.initialized = false;
      this.calibrationMode = false;
      this.calibrationTargetId = null;
    }

    init(containerId = 'ets-map-container') {
      const container = document.getElementById(containerId);
      if (!container) return;

      if (this.initialized && this.map) {
        // Immediate and staggered invalidation to guarantee full tile rendering without gray zones
        this.invalidateMapSize();
        return;
      }

      // Center on Davao Del Norte (Tagum / Sto. Tomas / Panabo sector)
      const ddnCenter = [7.4475, 125.8078];
      this.map = L.map(containerId, {
        center: ddnCenter,
        zoom: 11,
        zoomControl: true,
        preferCanvas: true
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors | NORTH-005 Davao Del Norte HQ'
      }).addTo(this.map);

      // Add booth markers layer
      this.markers.booths.addTo(this.map);

      // Handle window resize events
      if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
        window.addEventListener('resize', () => {
          if (this.map) this.map.invalidateSize();
        });
      }

      // Pin calibration click listener
      this.map.on('click', (e) => {
        if (this.calibrationTargetId) {
          this.setCoordinateForTarget(this.calibrationTargetId, e.latlng.lat, e.latlng.lng);
        }
      });

      this.initialized = true;
      this.renderAllMarkers();
      this.invalidateMapSize();
    }

    invalidateMapSize() {
      if (!this.map) return;
      setTimeout(() => { if (this.map) this.map.invalidateSize(); }, 50);
      setTimeout(() => { if (this.map) this.map.invalidateSize(); }, 200);
      setTimeout(() => { if (this.map) this.map.invalidateSize(); }, 450);
    }

    // Marker icon representing an STL BOOTH with municipality color
    createSvgIcon(color, glyphText = '🏪', isDraggable = false, title = 'STL BOOTH') {
      return L.divIcon({
        className: 'custom-ets-marker',
        html: `
          <div title="${title}" style="
            background: ${color};
            color: #ffffff;
            width: 34px;
            height: 34px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.35);
            border: 2px solid ${isDraggable ? '#f59e0b' : '#ffffff'};
            font-weight: 700;
            font-size: 13px;
            position: relative;
            cursor: ${isDraggable ? 'grab' : 'pointer'};
            ${isDraggable ? 'animation: pulse-border 1.5s infinite;' : ''}
          ">
            ${glyphText}
            <div style="
              position: absolute;
              bottom: -6px;
              left: 11px;
              width: 0;
              height: 0;
              border-left: 6px solid transparent;
              border-right: 6px solid transparent;
              border-top: 6px solid ${color};
            "></div>
          </div>
        `,
        iconSize: [34, 40],
        iconAnchor: [17, 40],
        popupAnchor: [0, -38]
      });
    }

    /**
     * Renders STL Booth markers deduplicated strictly by unique Booth Code.
     * Uses real Master Registry coordinates only.
     * Never plots collectors/admin (boothCode = '-') as booth markers.
     * Validates that Latitude is first and Longitude is second.
     */
    /**
     * Helper to render and bind a single booth marker.
     * Shared by both Cache-Hit and Cache-Miss pipelines.
     */
    _renderMarkerForBooth(boothData, isDraggable, isAdmin) {
      const { boothCode, lat, lng, municipality, location, status, staffList, boothRecordId } = boothData;
      const color = resolveMunicipalityColor(municipality);
      const boothDisplay = boothCode;
      const staffNames = staffList && staffList.length > 0 ? staffList.map(s => s.name).join(', ') : (boothData.personnel || 'Unassigned');
      const staffDetails = staffList && staffList.length > 0 ? staffList.map(s => {
        let r = s.role || 'Staff';
        const rU = r.toUpperCase();
        if (rU === 'TELLER' || rU === 'STATION TELLER') r = 'Sales Representative';
        return `<div style="font-size:12px; color:var(--text-main); margin-bottom:2px;">• <strong>${s.name}</strong> <span style="color:#64748b; font-size:11px;">(${r})</span></div>`;
      }).join('') : `<div style="font-size:12px; color:var(--text-main); margin-bottom:2px;">• <strong>${staffNames}</strong></div>`;

      const icon = this.createSvgIcon(color, '🏪', isDraggable, `STL BOOTH: ${boothDisplay} (${municipality})`);
      const marker = L.marker([lat, lng], {
        icon,
        draggable: isDraggable
      });

      marker.bindTooltip(`<strong>STL BOOTH:</strong> ${boothDisplay} • ${staffNames} (${municipality})`, { direction: 'top' });

      const primaryStaffId = (staffList && staffList[0]) ? staffList[0].id : (boothRecordId || boothCode);
      let adminActions = '';
      if (isAdmin) {
        adminActions = `
          <div style="margin-top: 8px; display: flex; gap: 6px;">
            <button onclick="window.openPrecisionCalibrateModal('${primaryStaffId}')" style="flex: 1; padding: 6px 10px; background: #2563eb; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 11.5px; font-weight: 700;">
              ✏️ Recalibrate Pin
            </button>
          </div>
        `;
      }

      marker.bindPopup(`
        <div style="font-family: inherit; min-width: 250px; line-height: 1.4;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
            <span style="font-size: 11px; font-weight: 800; text-transform: uppercase; background: ${color}; color: #ffffff; padding: 2px 8px; border-radius: 4px; letter-spacing: 0.5px;">
              STL BOOTH: ${boothDisplay}
            </span>
            <span style="font-size: 11.5px; font-weight: 700; color: ${color};">
              ● ${municipality}
            </span>
          </div>
          <div style="margin-bottom: 6px; padding: 6px 8px; background: rgba(0,0,0,0.04); border-radius: 4px;">
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; margin-bottom: 2px;">Assigned Personnel:</div>
            ${staffDetails}
          </div>
          <div style="font-size: 12px; margin-bottom: 3px;"><strong>Municipality:</strong> <span style="font-weight: 700; color: ${color};">${municipality}</span></div>
          <div style="font-size: 12px; margin-bottom: 3px;"><strong>Location / Address:</strong> ${location || '-'}</div>
          <div style="font-size: 12px; margin-bottom: 3px;"><strong>GPS Coordinates:</strong> <span style="font-family: monospace; font-weight: 700; color: #2563eb;">${lat.toFixed(6)}, ${lng.toFixed(6)}</span></div>
          <div style="font-size: 12px; margin-bottom: 4px;"><strong>Status:</strong> <span style="font-weight: 700; color: #16a34a;">● ${status}</span></div>
          ${adminActions}
        </div>
      `);

      // Index marker under canonical normBoothCode, raw variations, and all associated personnel
      this.allMarkerInstances[boothCode] = marker;
      this.allMarkerInstances[boothCode.replace('-', ' ')] = marker; // "DDN 754"
      this.allMarkerInstances[boothCode.replace('DDN-', '')] = marker; // "754"
      if (boothData.rawBoothCode) this.allMarkerInstances[boothData.rawBoothCode] = marker;
      if (boothRecordId) this.allMarkerInstances[boothRecordId] = marker;

      if (staffList) {
        staffList.forEach(s => {
          if (s.id) this.allMarkerInstances[s.id] = marker;
          if (s.name) this.allMarkerInstances[s.name.toLowerCase().trim()] = marker;
        });
      }

      this.markers.booths.addLayer(marker);
      return marker;
    }

    /**
     * Renders STL Booth markers deduplicated strictly by unique Booth Code.
     * Uses real Master Registry coordinates only.
     * Leverages Smart Caching for instant performance while guaranteeing authoritative Master Registry sync.
     * Never plots collectors/admin (boothCode = '-') as booth markers.
     * Validates that Latitude is first and Longitude is second.
     */
    renderAllMarkers(forceRefresh = false) {
      if (!this.map) return;
      const store = window.appStore;
      if (!store) return;

      if (forceRefresh && window.etsGpsCache) {
        window.etsGpsCache.invalidate();
      }

      this.markers.booths.clearLayers();
      this.allMarkerInstances = {};

      const isDraggable = this.calibrationMode;
      const isAdmin = window.authManager && window.authManager.isAdmin();
      const currentVersion = store.getMasterRegistryVersion();

      // 1. SMART CACHE CHECK
      const cached = window.etsGpsCache ? window.etsGpsCache.getValidData(currentVersion) : null;
      if (cached && !forceRefresh) {
        // Cache Hit: Render directly from pre-validated Master Registry cache
        cached.booths.forEach(b => {
          if (b.personnel === 'Unassigned' || !b.personnel || (b.status || '').toUpperCase() === 'INACTIVE' || (b.status || '').toUpperCase() === 'UNUSED') return;
          this._renderMarkerForBooth(b, isDraggable, isAdmin);
        });

        this.lastAuditSummary = cached.auditSummary || {
          totalMasterRegistryBooths: (cached.booths.length + (cached.uncoordinated ? cached.uncoordinated.length : 0)),
          recordsWithValidGps: cached.booths.length,
          recordsWithInvalidGps: 0,
          recordsWithMissingGps: cached.uncoordinated ? cached.uncoordinated.length : 0,
          estMarkersCreated: cached.booths.length,
          estMarkersMissing: cached.uncoordinated ? cached.uncoordinated.length : 0,
          validBoothCodes: cached.booths.map(b => b.boothCode),
          missingBoothCodes: cached.uncoordinated ? cached.uncoordinated.map(u => u.boothCode) : [],
          invalidBoothCodes: []
        };
        console.log(`[EtsGpsCache HIT] Rendered ${cached.booths.length} verified booth markers (Version: ${currentVersion})`);
        return;
      }

      // 2. CACHE MISS / REFRESH: Authoritative Parse from Master Registry
      const registeredBooths = store.getBooths() || [];
      const employees = store.getEmployees() || [];
      // Relievers, Admins, Supervisors, and Collectors have no booths or coordinates and are excluded from STL Booth GPS Map
      const operationalStaff = employees.filter(emp => {
        const r = (emp.role || '').toUpperCase();
        const bCode = (emp.boothCode || emp.booth || '').trim().toUpperCase();
        const hasBooth = bCode && bCode !== '-' && bCode !== 'N/A' && bCode !== 'NONE';
        const isRel = (r.includes('RELIEVER') || r.includes('RELIVER') || r.includes('BUFFER') || emp.id === 'DDN005-SR000' || (typeof window.isOfficialRelieverName === 'function' && window.isOfficialRelieverName(emp.name))) && !hasBooth;
        const isAdm = r.includes('ADMIN') || (emp.department || '').includes('admin');
        const isSup = r.includes('SUPERVISOR') || (emp.department || '').includes('sup');
        const isCol = r.includes('COLLECTOR') || (emp.department || '').includes('col');
        return !isRel && !isAdm && !isSup && !isCol && hasBooth;
      });

      // Collect all distinct booths keyed strictly by normalized Booth Code
      const boothMap = new Map();

      // Ingest Master Registry registered booths
      registeredBooths.forEach(b => {
        const normCode = normalizeBoothCode(b.id || b.code);
        if (!normCode) return; // Skip non-booth entries like '-'
        const bStatus = (b.status || '').toUpperCase();
        if (bStatus === 'INACTIVE' || bStatus === 'UNUSED') return; // Skip inactive and unused booths

        boothMap.set(normCode, {
          normBoothCode: normCode,
          rawBoothCode: b.id || b.code || normCode,
          boothRecord: b,
          municipality: b.municipality || '',
          address: b.area || b.address || '',
          status: b.status || 'Active',
          staffList: []
        });
      });

      // Associate assigned personnel to booths by normalized Booth Code
      operationalStaff.forEach(emp => {
        const normCode = normalizeBoothCode(emp.boothCode || emp.booth);
        if (!normCode) return; // Skip collectors, admins, and unassigned roaming personnel

        if (!boothMap.has(normCode)) {
          boothMap.set(normCode, {
            normBoothCode: normCode,
            rawBoothCode: emp.boothCode || emp.booth || normCode,
            boothRecord: null,
            municipality: emp.municipality || '',
            address: emp.address || emp.area || emp.purok || '',
            status: emp.status || 'Active',
            staffList: [emp]
          });
        } else {
          const entry = boothMap.get(normCode);
          if (!entry.staffList.some(s => s.id === emp.id)) {
            entry.staffList.push(emp);
          }
          if (!entry.municipality && emp.municipality) entry.municipality = emp.municipality;
          if (!entry.address && (emp.address || emp.area)) entry.address = emp.address || emp.area;
        }
      });

      const auditSummary = {
        totalMasterRegistryBooths: boothMap.size,
        recordsWithValidGps: 0,
        recordsWithInvalidGps: 0,
        recordsWithMissingGps: 0,
        estMarkersCreated: 0,
        estMarkersMissing: 0,
        validBoothCodes: [],
        missingBoothCodes: [],
        invalidBoothCodes: []
      };

      const validBoothsToCache = [];
      const uncoordinatedBoothsToCache = [];

      boothMap.forEach((entry, normBoothCode) => {
        // Exclude unassigned booths or booths without assigned active personnel
        if (!entry.staffList || entry.staffList.length === 0) {
          return; // Skip unassigned booths from live tracking!
        }
        const hasActiveStaff = entry.staffList.some(s => (s.status || 'ACTIVE').toUpperCase() === 'ACTIVE' && s.name && s.name !== 'N/A' && s.name !== '-');
        if (!hasActiveStaff) {
          return; // Skip booths without active staff!
        }
        const entryStatus = (entry.status || '').toUpperCase();
        if (entryStatus === 'INACTIVE' || entryStatus === 'UNUSED') {
          return; // Skip inactive and unused booths!
        }

        // Resolve GPS Coordinates from the Master Registry records for this booth
        // Priority 1: Registered booth record in Master Registry
        let gps = { isValid: false };
        if (entry.boothRecord) {
          gps = parseGpsCoordinates(entry.boothRecord);
        }

        // Priority 2: Assigned staff records for this booth
        if (!gps.isValid && entry.staffList.length > 0) {
          for (const s of entry.staffList) {
            const altGps = parseGpsCoordinates(s);
            if (altGps.isValid) {
              gps = altGps;
              break;
            }
          }
        }

        // Priority 3: Authoritative check against Master Registry Authentic Coordinates dictionary
        if (!gps.isValid) {
          const authDict = (typeof AUTHENTIC_MASTER_REGISTRY_COORDINATES !== 'undefined')
            ? AUTHENTIC_MASTER_REGISTRY_COORDINATES
            : ((typeof window !== 'undefined' && window.AUTHENTIC_MASTER_REGISTRY_COORDINATES) ? window.AUTHENTIC_MASTER_REGISTRY_COORDINATES : (typeof global !== 'undefined' && global.AUTHENTIC_MASTER_REGISTRY_COORDINATES ? global.AUTHENTIC_MASTER_REGISTRY_COORDINATES : null));
          if (authDict) {
            const authEntry = authDict[normBoothCode] || (entry.rawBoothCode ? authDict[entry.rawBoothCode] : null) || authDict[normBoothCode.replace('DDN-', '')];
            if (authEntry && typeof authEntry.lat === 'number' && typeof authEntry.lng === 'number') {
              const dictGps = parseGpsCoordinates(authEntry);
              if (dictGps.isValid) {
                gps = dictGps;
                if (authEntry.municipality && (!entry.municipality || entry.municipality === '-')) {
                  entry.municipality = authEntry.municipality;
                }
              }
            }
          }
        }

        // Section 11 & 12: If no valid GPS coordinates exist in Master Registry, DO NOT place on map!
        // Record and log the specific Booth Code for diagnostic tracking
        if (!gps.isValid) {
          const reason = gps.reason || 'GPS UNAVAILABLE';
          if (reason.includes('INVALID') || reason.includes('BOUNDS')) {
            auditSummary.recordsWithInvalidGps++;
            auditSummary.invalidBoothCodes.push(normBoothCode);
          } else {
            auditSummary.recordsWithMissingGps++;
            auditSummary.missingBoothCodes.push(normBoothCode);
          }
          auditSummary.estMarkersMissing++;
          uncoordinatedBoothsToCache.push({
            boothCode: normBoothCode,
            municipality: entry.municipality || '-',
            reason
          });
          return;
        }

        auditSummary.recordsWithValidGps++;
        auditSummary.estMarkersCreated++;
        auditSummary.validBoothCodes.push(normBoothCode);

        const lat = gps.lat;
        const lng = gps.lng;

        // Resolve Municipality
        let muni = entry.municipality;
        if (!muni || muni === '-') {
          const addr = (entry.address || '').toLowerCase();
          if (addr.includes('panabo')) muni = 'Panabo City';
          else if (addr.includes('tomas') || addr.includes('tibal') || addr.includes('feeder')) muni = 'Sto. Tomas';
          else if (addr.includes('carmen')) muni = 'Carmen';
          else if (addr.includes('kapalong')) muni = 'Kapalong';
          else if (addr.includes('tagum')) muni = 'Tagum City';
          else if (addr.includes('talaingod')) muni = 'Talaingod';
          else if (addr.includes('samal')) muni = 'Samal';
          else muni = 'Sto. Tomas';
        }

        const boothData = {
          boothCode: normBoothCode,
          rawBoothCode: entry.rawBoothCode,
          lat,
          lng,
          municipality: muni,
          location: entry.address || '-',
          status: entry.status || 'Active',
          personnel: entry.staffList.length > 0 ? entry.staffList.map(s => s.name).join(', ') : 'Unassigned',
          staffList: entry.staffList.map(s => ({ id: s.id, name: s.name, role: s.role })),
          boothRecordId: entry.boothRecord ? entry.boothRecord.id : null
        };

        this._renderMarkerForBooth(boothData, isDraggable, isAdmin);
        validBoothsToCache.push(boothData);
      });

      this.lastAuditSummary = auditSummary;

      // Populate Smart Cache with validated records
      if (window.etsGpsCache) {
        window.etsGpsCache.setData(currentVersion, validBoothsToCache, uncoordinatedBoothsToCache, auditSummary);
      }

      console.log(`[ETS GPS Audit Summary] Total Master Registry Booths: ${auditSummary.totalMasterRegistryBooths} | Valid GPS: ${auditSummary.recordsWithValidGps} | Missing GPS: ${auditSummary.recordsWithMissingGps} | Invalid GPS: ${auditSummary.recordsWithInvalidGps} | EST Markers Rendered: ${auditSummary.estMarkersCreated} | Missing Markers: ${auditSummary.estMarkersMissing}`);
    }

    // Draggable Calibration Mode
    toggleCalibrationMode() {
      this.calibrationMode = !this.calibrationMode;
      this.renderAllMarkers();

      const banner = document.getElementById('ets-calibration-banner');
      if (banner) {
        banner.style.display = this.calibrationMode ? 'flex' : 'none';
      }
    }

    focusCoordinates(lat, lng, zoom = 15) {
      if (!this.map) return;
      this.map.setView([lat, lng], zoom, { animate: true });
      this.invalidateMapSize();
    }
  }

  window.etsMap = new EtsMapEngine();
  window.getEtsGpsAuditReport = function() {
    return window.etsMap ? window.etsMap.lastAuditSummary : null;
  };

  /**
   * Section 18: GPS Synchronization Validation
   * Validates that for each booth:
   * Booth Code, Master Registry GPS, EST GPS (Cache), and Map Marker GPS all match.
   */
  window.validateEtsGpsSync = function() {
    const store = window.appStore;
    if (!store) return { success: false, reason: 'Store not loaded' };
    const etsEngine = window.etsMap;
    const version = store.getMasterRegistryVersion();
    const registeredBooths = store.getBooths() || [];
    const employees = store.getEmployees() || [];
    const results = [];
    let discrepancies = 0;

    // Check every registered booth that has coordinates in Master Registry
    registeredBooths.forEach(b => {
      const bCode = normalizeBoothCode(b.id || b.code);
      if (!bCode) return;
      const bStatus = (b.status || '').toUpperCase();
      if (bStatus === 'INACTIVE' || bStatus === 'UNUSED') return;

      const mrGps = parseGpsCoordinates(b);
      const emp = employees.find(e => normalizeBoothCode(e.boothCode || e.booth) === bCode);
      const effectiveMrGps = mrGps.isValid ? mrGps : (emp ? parseGpsCoordinates(emp) : { isValid: false });

      if (!effectiveMrGps.isValid) {
        // Uncoordinated booth - ensure no rogue marker was rendered
        const marker = etsEngine && etsEngine.allMarkerInstances ? etsEngine.allMarkerInstances[bCode] : null;
        if (marker) {
          discrepancies++;
          results.push({
            boothCode: bCode,
            status: 'DISCREPANCY_ORPHAN_MARKER',
            error: 'Booth has no valid GPS in Master Registry but has a rendered marker!'
          });
        }
        return;
      }

      const mrLat = effectiveMrGps.lat;
      const mrLng = effectiveMrGps.lng;

      // Check EST GPS from cache
      const cached = window.etsGpsCache ? window.etsGpsCache.getValidData(version) : null;
      let estLat = null;
      let estLng = null;
      if (cached && Array.isArray(cached.booths)) {
        const cBooth = cached.booths.find(cb => cb.boothCode === bCode);
        if (cBooth) {
          estLat = cBooth.lat;
          estLng = cBooth.lng;
        }
      } else {
        estLat = mrLat;
        estLng = mrLng;
      }

      // Check Map Marker GPS
      const marker = etsEngine && etsEngine.allMarkerInstances ? etsEngine.allMarkerInstances[bCode] : null;
      let markerLat = null;
      let markerLng = null;
      if (marker && typeof marker.getLatLng === 'function') {
        const pos = marker.getLatLng();
        markerLat = parseFloat(Number(pos.lat).toFixed(6));
        markerLng = parseFloat(Number(pos.lng).toFixed(6));
      }

      const match = (markerLat !== null && markerLng !== null) &&
                    (mrLat === markerLat && mrLng === markerLng) &&
                    (estLat === null || (mrLat === estLat && mrLng === estLng));

      if (!match) discrepancies++;

      results.push({
        boothCode: bCode,
        masterRegistryGps: `${mrLat}, ${mrLng}`,
        estGps: estLat !== null ? `${estLat}, ${estLng}` : 'N/A',
        mapMarkerGps: markerLat !== null ? `${markerLat}, ${markerLng}` : 'MISSING_MARKER',
        status: match ? 'SYNCED' : 'MISMATCH'
      });
    });

    return {
      success: discrepancies === 0,
      discrepancies,
      totalChecked: results.length,
      version,
      details: results
    };
  };

})();
