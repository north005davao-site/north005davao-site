# NORTH-005 DAVAO DEL NORTE HQ — SYSTEM RECOVERY & RESTORATION MANUAL

**Backup ID:** `BKP-20261009145800-416365`
**Version:** `v1.4.0-test-baseline`
**Created At:** 2026-10-09T14:58:00.770Z
**Backup Type:** `full`
**Checksum (SHA-256):** `Generated on packaging`

---

## 1. INCLUDED COMPONENTS SUMMARY
- **Source Code Files:** YES (HTML, CSS, JS, Node Server, Vercel Serverless)
- **Operational Data Records:** YES (Master Registry, Transactions, Outlets, Documents, SQL Schema)
- **Operational Records Captured:**
  - **Master Registry Employees:** 158
  - **Financial Transactions:** 2
  - **Outlet Rentals & Leases:** 0
  - **Employee 201 Compliance Docs:** 46

---

## 2. SECURITY SANITIZATION NOTICE
- **Plaintext Passwords & Active Session Tokens:** Stripped and sanitized with secure placeholders.
- **Supabase Credentials:** Public client anon keys are documented in `js/supabase-client.js`.
- **Environment Variables:** Documented in `vercel.json` and `server.js`. Reconfigure service tokens as needed upon cloud migration.

---

## 3. HOW TO RESTORE

### OPTION A: Restore via Browser Control Center (Recommended for Non-Developers)
1. Open the ERP web application at `https://north005davao.site` (or your local instance).
2. Log in as an Administrator (`admin` / `Peter John Carrillo`).
3. In the sidebar, navigate to **Backup & Restore**.
4. In the **Upload Backup File** box, select or drag this `.zip` archive.
5. Review the validation summary and integrity checks.
6. Select your restoration scope:
   - **Operational Data Only** (Safest: restores database records without touching code files)
   - **Full System** (Restores both code and data)
   - **Code Only** (Restores code files without modifying the live database)
7. Click **Confirm & Restore**. The system automatically generates a safety backup before restoring and verifies system health immediately after.

---

### OPTION B: Restore to a Local Node.js Server
1. Extract this `.zip` archive into a new directory (e.g. `C:\omni-erp-restored`).
2. Open a terminal in that folder:
   ```bash
   npm install
   node server.js
   ```
3. Open your browser to: `http://localhost:3000`
4. The system is immediately operational with all restored registry, transactions, and modules.

---

### OPTION C: Restore to Vercel (Production Cloud Hosting)
1. Ensure your local folder is synced with your GitHub repository:
   ```bash
   git add .
   git commit -m "Restore to backup BKP-20261009145800-416365"
   git push origin main
   ```
2. Vercel will automatically build and deploy the production bundle to `https://north005davao.site`.
3. Check the Vercel dashboard to verify deployment health.

---

### OPTION D: Restore Supabase Database
1. Open your Supabase project dashboard at `https://supabase.com/dashboard`.
2. Navigate to the **SQL Editor**.
3. If table structures need recreation, run the included script: `data/supabase_schema.sql`.
4. If restoring operational data directly into Supabase, the server and client will automatically synchronize the restored JSON records on startup.

---

## 4. INTEGRITY & VERIFICATION
Every file in this backup has been cryptographically hashed with SHA-256. 
You can verify file integrity at any time using:
```bash
node scripts/backup_engine.js verify --file "BKP-20261009145800-416365.zip"
```
